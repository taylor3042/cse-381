﻿namespace AlgorithmLib;

public static class QuickSort
{
    private static int Partition(List<IComparable> data, int first, int last)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return -1;
    }

    public static void Sort(List<IComparable> data)
    {
        // ADD CODE HERE
    }

}