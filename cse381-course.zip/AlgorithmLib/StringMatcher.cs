﻿using Microsoft.VisualBasic.CompilerServices;

namespace AlgorithmLib;

public static class StringMatcher
{
    private static List<Dictionary<char, int>> BuildTable(string pattern, List<char> inputs)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return new List<Dictionary<char, int>>();
    }
    
    public static List<int> Match(string text,  string pattern, List<char> inputs)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return new List<int>();
    }
    
}