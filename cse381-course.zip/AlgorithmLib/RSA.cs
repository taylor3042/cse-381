﻿using System.Numerics;

namespace AlgorithmLib;

public class RSA
{
    private static (BigInteger, BigInteger, BigInteger) Euclid(BigInteger a, BigInteger b)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return (-1, -1, -1);
    }

    private static BigInteger ModularExponentiation(BigInteger x, BigInteger y, BigInteger n)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return -1;
    }

    public static BigInteger GeneratePrivateKey(BigInteger p, BigInteger q, BigInteger e) 
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return -1;
    }

    public static BigInteger Encrypt(BigInteger value, BigInteger e, BigInteger n)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return -1;
    }

    public static BigInteger Decrypt(BigInteger value, BigInteger d, BigInteger n)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return -1;
    }


}