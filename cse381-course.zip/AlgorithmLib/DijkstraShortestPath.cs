﻿namespace AlgorithmLib;

public static class DijkstraShortestPath
{

    public static (List<int>, List<int>) ShortestPath(Graph g, int startVertex)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return (new List<int>(), new List<int>());
    } 
}