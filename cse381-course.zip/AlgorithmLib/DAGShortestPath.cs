﻿using System.Runtime.CompilerServices;

namespace AlgorithmLib;


public static class DAGShortestPath
{
    public static (List<int>, List<int>) ShortestPath(Graph g, int startVertex)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return (new List<int>(), new List<int>());
    } 
    
}