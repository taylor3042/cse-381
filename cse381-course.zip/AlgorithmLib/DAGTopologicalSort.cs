﻿using System.Collections;

namespace AlgorithmLib;

public static class DAGTopologicalSort
{
    public static List<int> Sort(Graph g)
    {
        // ADD CODE HERE AND FIX RETURN STATEMENT
        return new List<int>();
    } 
}