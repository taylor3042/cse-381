﻿namespace AlgorithmLib;

public static class MergeSort
{
    private static void Merge(List<IComparable> data, int first, int mid, int last)
    {
        // ADD CODE HERE 
    }

    public static void Sort(List<IComparable> data)
    {
        // ADD CODE HERE 
    }
    
}

